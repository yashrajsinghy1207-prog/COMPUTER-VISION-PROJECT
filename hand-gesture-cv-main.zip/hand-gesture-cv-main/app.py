"""
app.py — Main Application Entry Point

Orchestrates the full pipeline:
    Webcam Capture → Hand Detection → Gesture Recognition → Visualization → Display

Keyboard controls
-----------------
  Q  : quit the application
  S  : save a screenshot to screenshots/
  D  : toggle debug mode (show landmark indices)

Error handling
--------------
  - Webcam missing / busy   → RuntimeError with actionable message
  - Frame read failure      → warning logged, loop continues
  - No hand detected        → on-screen warning shown, loop continues
  - KeyboardInterrupt       → clean shutdown
"""

from __future__ import annotations

import logging
import sys

import cv2

import config
from detector import HandDetector, WebcamCapture
from gesture_recognizer import GestureRecognizer
from utils import FPSCounter, save_screenshot, setup_logger
from visualizer import Visualizer


class App:
    """
    Encapsulates the full application lifecycle so it can be unit-tested
    or run in non-webcam contexts by swapping the video source.
    """

    def __init__(self) -> None:
        self.logger     = setup_logger()
        self.detector   = HandDetector()
        self.recognizer = GestureRecognizer()
        self.visualizer = Visualizer()
        self.fps_counter = FPSCounter()
        self._debug_mode = False
        self.logger.info("App initialised. Press Q to quit, S to screenshot, D to toggle debug.")

    # ------------------------------------------------------------------
    # Main Loop
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Open the webcam and run the real-time detection loop."""
        try:
            with WebcamCapture() as cap:
                self._loop(cap)
        except RuntimeError as exc:
            self.logger.error("Camera error: %s", exc)
            print(f"\n[ERROR] {exc}\n", file=sys.stderr)
        except KeyboardInterrupt:
            self.logger.info("Interrupted by user (Ctrl+C).")
        finally:
            self.detector.close()
            cv2.destroyAllWindows()
            self.logger.info("Application shut down cleanly.")

    def _loop(self, cap: cv2.VideoCapture) -> None:
        """Inner frame-processing loop (separated for testability)."""
        window_name = "Hand Gesture Recognition  |  Q=Quit  S=Screenshot  D=Debug"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, config.FRAME_WIDTH, config.FRAME_HEIGHT)

        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                self.logger.warning("Failed to read frame from camera; retrying.")
                continue

            # Mirror for natural interaction (webcam is left-right flipped)
            frame = cv2.flip(frame, 1)
            self.fps_counter.tick()

            # --- Detection ---------------------------------------------------
            hand_results = self.detector.detect(frame)

            # --- Recognition + Visualization ---------------------------------
            if hand_results:
                hand = hand_results[0]   # use first detected hand
                gesture_result = self.recognizer.classify(hand.landmarks, hand.handedness)

                frame = self.visualizer.draw_landmarks(
                    frame, hand.landmarks, show_indices=self._debug_mode
                )
                frame = self.visualizer.draw_gesture_label(frame, gesture_result)
                frame = self.visualizer.draw_handedness(frame, hand.handedness)
            else:
                frame = self.visualizer.draw_no_hand(frame)

            # --- Overlays ----------------------------------------------------
            frame = self.visualizer.draw_fps(frame, self.fps_counter.fps)
            frame = self.visualizer.draw_info_panel(frame, self._debug_mode)

            # --- Display -----------------------------------------------------
            cv2.imshow(window_name, frame)

            # --- Keyboard Input ----------------------------------------------
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q") or key == 27:       # Q or ESC
                self.logger.info("Quit requested by user.")
                break
            elif key == ord("s"):
                path = save_screenshot(frame)
                if path:
                    self.logger.info("Screenshot saved to: %s", path)
            elif key == ord("d"):
                self._debug_mode = not self._debug_mode
                self.logger.info("Debug mode: %s", "ON" if self._debug_mode else "OFF")


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------

def main() -> None:
    app = App()
    app.run()


if __name__ == "__main__":
    main()
